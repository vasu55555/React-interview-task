import React, {useState} from "react";
import './App.css';
import Home from "./Home"; 
import {BrowserRouter, Routes, redirect, Route} from "react-router-dom";


function App() {
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [emailError, setEmailError] = useState("");

  const handleValidation = (event)=>{
    let formIsValid = true;
    if(!email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/)){
      formIsValid = false;
      setEmailError("email not valid");
      return false;
    } else {
      setEmailError("");
      formIsValid = true;
    }

    if(!password.match(/^[a-zA-Z]{8,22}$/)){
      formIsValid = false;
      setPasswordError(
        "please check the charatcters in password length"
      );
      return false;
    } else {
      setPasswordError("");
      formIsValid = true;
    }
    return formIsValid;
  }

  const loginSubmit =(e)=>{
    e.preventDefault();
    handleValidation();
  }

  const clickHandler=()=>{
  <redirect to="/Home"/>
  }


  return (
    <div className="App">
      
      
      <Routes>
      <Route  path="/home" element={<Home/>}/>
    </Routes>
      {/* <Home/> */}
        <div className="container">
            <div className="row-d-flex justify-content-center">
              <div className="col-md-4">
                <form id="loginform" onSubmit={loginSubmit}>
                  <div className="form-group">
                    <label>Email</label>
                    <input 
                    type="text"
                    className="form-control"
                    id="EmailInput"
                    placeholder="Email"
                    aria-describedby="emailHelp"
                    onChange={(event) => setEmail(event.target.value)}/>

                  </div>
                  <div className="form-group">
                    <label>Password</label>
                    <input 
                    type="password"
                    className="form-control"
                    id="exampleInputpassword"
                    placeholder="password"
                    onChange={(event) => setPassword(event.target.value)}/>

                  </div>
                  <small id="passworderror" className="text-danger form-text">
                    {passwordError}
                  </small>
                  <div className="form-group form-check"> 
                  <input type="checkbox" className="form-check-input"/>
                  <label className="form-check-label">check me on</label></div>
                  <button type="submit" className="btn btn-primary">Submit</button>

                </form>

              </div>

            </div>

        </div>

    
        
        <button onClick={clickHandler}>Click me</button>        
    </div>
  );
}

export default App;
