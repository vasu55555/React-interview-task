import React from "react";
const Sidebar=({ openClass })=>{
    return(
        <nav className={openClass === 'open' ? 'openSidebar' : ''}>
            <ul className="navlist">
                <li>
                    <a className="menu-item" href="/">Home</a>
                </li>
                <li>
                    <a className="menu-item" href="/">Services</a>
                </li>
                <li>
                    <a className="menu-item" href="/">About</a>
                </li>
                <li>
                    <a className="menu-item" href="/">Contact</a>
                </li>

            </ul>

        </nav>
    )
};

export default Sidebar;