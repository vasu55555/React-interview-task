import React,{useState, useEffect} from "react";
import axios from 'axios';
import Sidebar from "./Components/Sidebar";


const Home=()=>{
    const [on, setOn] = useState(false)
    const [data, setData] = useState([]);

    const handleOn=()=>{
        setOn(!on);
    }

    useEffect(()=>{
        axios.get("https://jsonplaceholder.typicode.com/todos/").then(response => setData(response.data))
    },[])
    return(
        <div>
            <aside className={on ? 'to-right' : ''}>
                <a href="#" onClick={handleOn}>
                click it
                </a>
                <h1>React Sidebar</h1>
            </aside>
            {on && <Sidebar openClass="open"/>}
            <table>
                <tr>
                    <td>ID</td>
                    <td>userId</td>
                    <td>title</td>
                    <td>Status</td>
                </tr>
                {data.map((item, index) => (
                    <tr data-index= {index}>
                        <td>{item.id}</td>
                        <td>{item.userId}</td>
                        <td>{item.title}</td>
                        <td>{item.completed}</td>
                    </tr>
                ))}
            </table>
            

        </div>
    );

}

export default Home;